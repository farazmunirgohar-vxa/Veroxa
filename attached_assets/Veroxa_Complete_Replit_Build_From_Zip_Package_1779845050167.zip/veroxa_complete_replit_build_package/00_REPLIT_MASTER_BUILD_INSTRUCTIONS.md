# Veroxa Master Build Instructions for Replit

## Goal

Build Veroxa as a premium restaurant marketing operating system with:

1. Public website
2. Client Portal
3. Team Portal
4. Operator Portal
5. Owner Portal
6. Placeholder auth/demo access gate
7. Supabase-ready backend architecture
8. SQL draft/test package workflow
9. Demo data mode first
10. Real backend activation only after tested migrations

## Non-negotiable rules

Do NOT:
- activate real auth unless explicitly asked
- set AUTH_MODE to "real"
- change locked pricing
- change role names
- use "Super Admin"
- connect live publishing APIs
- connect AI APIs before the AI phase
- run M002+ migrations without review
- issue real client credentials
- remove demo access gate
- expose internal owner/team/operator info in Client Portal
- replace stable architecture with random scaffold

Keep:
```ts
export const AUTH_MODE: AuthMode = "placeholder";
```

## App style

Premium dark SaaS.
Clean, minimal, professional, trust-building.
Restaurant owner-friendly language.
No technical jargon in client-facing UI.

## Required routes

Public:
- `/`
- `/pricing`
- `/services`
- `/contact`
- `/login`

Demo Client:
- `/demo/client/dashboard`
- `/demo/client/media`
- `/demo/client/calendar`
- `/demo/client/reports`
- `/demo/client/requests`
- `/demo/client/account`

Demo Team:
- `/demo/team/dashboard`
- `/demo/team/work-queue`
- `/demo/team/media-review`
- `/demo/team/drafts`
- `/demo/team/scheduling`
- `/demo/team/report-queue`
- `/demo/team/alerts`

Demo Operator:
- `/demo/operator/operator-os`
- `/demo/operator/client-health`
- `/demo/operator/alerts`
- `/demo/operator/report-approvals`
- `/demo/operator/media-library`
- `/demo/operator/team-oversight`
- `/demo/operator/system-status`

Demo Owner:
- `/demo/owner/executive-dashboard`
- `/demo/owner/revenue`
- `/demo/owner/client-health`
- `/demo/owner/alerts`
- `/demo/owner/ai-agents-v2`
- `/demo/owner/owner-os`
- `/demo/owner/settings`

## Portal access behavior

Client Portal:
- Public preview, no access code

Team / Operator / Owner:
- Require demo-only access gate while AUTH_MODE = "placeholder"
- Access code:
```text
veroxa-preview
```
- localStorage key:
```text
veroxa_demo_internal_access
```

This is not real auth. It is only demo protection.

## Build strategy

If building from scratch:

1. Build public website and demo portal shell
2. Build demo data structure
3. Add placeholder auth + demo internal gate
4. Add role-based navigation
5. Add pricing page with locked pricing
6. Add backend docs and SQL drafts
7. Prepare M002 dev Supabase package
8. Stop for review

If continuing existing repo:

1. Pull latest GitHub main
2. Verify AUTH_MODE is placeholder
3. Verify demo access gate exists
4. Verify M001 status
5. Prepare M002 dev Supabase package only
