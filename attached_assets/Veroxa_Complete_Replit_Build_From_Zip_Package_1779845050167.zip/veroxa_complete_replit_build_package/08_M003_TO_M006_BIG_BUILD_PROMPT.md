# Larger Replit Build Prompt — Prepare M003–M006 Dev Test Packages

Use only after M002 is reviewed and ideally tested green.

Objective:
Prepare dev Supabase test packages for M003 through M006.

Do not run migrations.
Do not connect app.
Do not change AUTH_MODE.
Do not change UI/pricing/nav.

Create folders:

artifacts/veroxa/docs/sql_drafts/dev_test_m003/
artifacts/veroxa/docs/sql_drafts/dev_test_m004/
artifacts/veroxa/docs/sql_drafts/dev_test_m005/
artifacts/veroxa/docs/sql_drafts/dev_test_m006/

Each folder must include:
- README.md
- 01_apply_m00X.sql
- 02_seed_m00X_dev_data.sql
- 03_test_m00X_queries.sql
- 04_m00X_test_results.md

## M003
Use:
- 003_media_foundation_draft.sql
- 003_notifications_status_guard_draft.sql

Include:
- media_assets
- notifications
- client_health_snapshots
- activity_logs
- notification status guard

## M004
Use:
- 004_posting_foundation_draft.sql
- 004_post_slot_reset_guard_draft.sql

Include:
- posts
- post_slots
- media_assets.linked_post_id FK
- post slot reset guard

## Portal Connect
Create separate:
artifacts/veroxa/docs/sql_drafts/dev_test_portal_connect/

Include:
- apply portal-connect views SQL
- test portal views SQL
- results sheet

## M005
Use:
- 005_reporting_foundation_draft.sql

Include:
- weekly_reports
- monthly_reports
- report views

## M006
Use:
- 006_content_ai_layer_draft.sql

Include:
- content_concepts
- draft_sets
- draft_variants
- ai_agents

## Safety

All generated files are human-run packages only.
Never apply automatically.
