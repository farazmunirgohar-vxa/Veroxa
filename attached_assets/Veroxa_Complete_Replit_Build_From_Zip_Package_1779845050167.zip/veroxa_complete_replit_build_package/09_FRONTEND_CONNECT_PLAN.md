# Frontend Supabase Connect Plan

Only start after M001 and M002 are green.

## Phase A — keep placeholder auth

Do not flip AUTH_MODE yet.

Add data repository layer:
- src/lib/repositories/clientRepository.ts
- src/lib/repositories/mediaRepository.ts
- src/lib/repositories/reportRepository.ts
- src/lib/repositories/requestRepository.ts

Each repository should have:
- demo implementation
- future Supabase implementation

## Phase B — Client Portal safe views only

Client portal must query only:
- client_portal_clients_view
- client_portal_platforms_view
- client_portal_onboarding_view
- client_portal_requests_view
- client_portal_media_view
- client_portal_notifications_view
- client_portal_health_view
- client_portal_calendar_view
- client_portal_weekly_reports_view
- client_portal_monthly_reports_view

Never query base tables from client portal:
- clients
- media_assets
- posts
- weekly_reports
- monthly_reports
- activity_logs
- content_concepts
- draft_sets
- draft_variants

## Phase C — real auth

Flip AUTH_MODE to "real" only after:
- M001-M004 green
- portal-connect views green
- test users per role created
- login/logout tested
- rollback plan exists
