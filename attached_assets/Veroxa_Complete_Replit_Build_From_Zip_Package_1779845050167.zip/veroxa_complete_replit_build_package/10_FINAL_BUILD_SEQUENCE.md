# Veroxa Final Build Sequence

## Current next step

Prepare M002 dev test package.

## Sequence

1. M002 package generation
2. Human review
3. Apply M002 in dev Supabase
4. Run M002 tests
5. If green, prepare M003 package
6. Apply M003 in dev
7. Run M003 tests
8. Apply notifications status guard
9. Run guard tests
10. Prepare/apply M004
11. Apply post slot reset guard
12. Portal-connect views
13. M005 reports
14. M006 content/AI schema
15. Frontend repository layer
16. Connect Client Portal to safe views
17. Connect Team/Operator/Owner to base/role-safe tables
18. Real auth QA
19. Flip AUTH_MODE to real
20. Test full login routing
21. Prepare first pilot client

## Do not skip

Do not skip portal-connect views before real client login.
