# Veroxa Product Requirements

## Product Definition

Veroxa is a restaurant marketing operating system that helps restaurants maintain a complete online presence with minimal daily effort from the owner.

The restaurant uploads media. Veroxa handles content review, captions, scheduling, Google presence, reports, and operational visibility.

## Core promise

Restaurant owner:
"Upload fresh restaurant content. Veroxa handles the system."

## Roles

### Client
Restaurant owner/user.

They should see:
- Dashboard
- Upload Media
- Calendar
- Reports
- Requests
- Account

They should NOT see:
- internal team queues
- operator notes
- owner revenue
- AI internals
- draft variants
- raw risk scoring
- internal rejection details

### Team
Execution team.

They should see:
- Work queue
- Media review
- Drafting
- Scheduling
- Reports
- Alerts

They should NOT see:
- owner revenue
- pricing controls
- role permissions
- strategic owner settings

### Operator
Operations lead.

They should see:
- Client health
- Alerts
- Report approvals
- Media oversight
- Team workload
- System status

They should NOT be forced to approve every post.

### Owner
Business owner.

They should see:
- Revenue
- Active clients
- Growth
- Retention
- Critical alerts
- AI/system health
- Client risk

They should NOT see daily execution noise as the main experience.

## Locked tone

Premium, calm, clear, trust-building.

Avoid:
- hype
- fake results
- overpromising
- technical jargon for clients
- "admin/super admin" language

Use:
- Owner
- Operator
- Team
- Client
