# Veroxa Current Checkpoint

## Completed

### Business / Offer
- Veroxa brand locked
- Restaurant-focused positioning locked
- Pricing locked
- Islamic/ethical business foundation locked
- Role structure locked

### Frontend / Demo
- Public website exists or should be built
- Client portal demo exists or should be built
- Team portal demo exists or should be built
- Operator portal demo exists or should be built
- Owner portal demo exists or should be built
- Mobile polish mostly handled
- Client portal should be simple and not expose internal operations
- Team portal should be execution-focused
- Operator portal should be oversight-focused
- Owner portal should be executive-focused

### Auth / Access
- AUTH_MODE remains placeholder
- Client demo is public
- Team/Operator/Owner use demo access gate
- Access code: veroxa-preview

### Backend Planning
- Demo data split done conceptually
- M001 through M006 planned
- M001 Identity Foundation applied and tested in dev Supabase
- M001 marked green enough after testing:
  - anon blocked
  - client own-only
  - team own-only
  - operator read-only
  - owner management
  - role escalation blocked
  - email tampering blocked

## Not Done Yet

- M002 not applied
- M003 not applied
- M004 not applied
- M005 not applied
- M006 not applied
- Portal not connected to Supabase
- Real auth not active
- Real uploads not active
- Real AI APIs not active
- Real publishing not active
- Payments not active

## Next best task

Prepare the M002 dev Supabase test package only.

Do not apply it yet.
