# Demo Data Structure

If building from scratch, create:

src/data/demo/
  demoClients.ts
  demoClientPlatforms.ts
  demoOnboarding.ts
  demoMediaAssets.ts
  demoContentConcepts.ts
  demoDraftSets.ts
  demoDraftVariants.ts
  demoPosts.ts
  demoPostSlots.ts
  demoNotifications.ts
  demoWeeklyReports.ts
  demoMonthlyReports.ts
  demoActivityLogs.ts
  demoClientHealth.ts
  demoRequests.ts
  demoFinancials.ts
  demoAgents.ts
  demoTeam.ts
  demoSystemStatus.ts
  demoPricing.ts
  index.ts

Keep `src/data/demoData.ts` as compatibility barrel:

```ts
export * from "./demo";
```

## Demo client examples

Use restaurant examples only. Avoid real client private data.

Example:
- Mamadali Kebab House
- San Antonio sample restaurant
- Demo taco shop
- Demo bakery

## Purpose

Demo data should map to future backend tables:

- demoClients -> clients
- demoMediaAssets -> media_assets
- demoPosts -> posts
- demoPostSlots -> post_slots
- demoWeeklyReports -> weekly_reports
- demoMonthlyReports -> monthly_reports
- demoNotifications -> notifications
- demoActivityLogs -> activity_logs
- demoAgents -> ai_agents
