# Replit Prompt — Prepare M002 Dev Supabase Test Package

Objective:
Prepare the M002 dev Supabase test package only.

Do NOT apply M002.
Do NOT run migrations.
Do NOT connect the portal.
Do NOT change AUTH_MODE.
Do NOT change UI.
Do NOT change pricing.
Do NOT change navigation.

M001 has already been applied and tested in dev Supabase.

## Required output folder

Create:

artifacts/veroxa/docs/sql_drafts/dev_test_m002/

Files:
- README.md
- 01_apply_m002.sql
- 02_seed_m002_dev_data.sql
- 03_test_m002_queries.sql
- 04_m002_test_results.md

## Source SQL

Use existing draft:

docs/sql_drafts/migrations_review/002_client_foundation_draft.sql

Convert it into clean human-executable test SQL:
- keep comments
- remove DO NOT RUN header only in the dev_test copy
- do not alter schema logic unless required for test execution
- do not include M001
- do not include M003+

## M002 includes

- clients
- team_client_assignments
- client_platforms
- onboarding_items
- client_requests
- user_profiles.client_id FK
- helper functions:
  - is_assigned_to_client
  - can_view_client
  - can_manage_client_operations
  - can_manage_pricing

## Seed data

Use fake dev data only.

Assume M001 dev users already exist:
- client@veroxa.test
- team@veroxa.test
- operator@veroxa.test
- owner@veroxa.test

Seed:
- 2 demo clients
- one client linked to client user
- team assigned to one client
- operator assigned where needed
- sample platforms
- sample onboarding items
- sample client requests

Do not use real restaurant private data.

## Tests

Create runnable SQL blocks with:
```sql
begin;
set local role authenticated;
set local "request.jwt.claims" = '{"sub":"...","role":"authenticated"}';
...
rollback;
```

Test:
- client sees own client only
- client cannot see other clients
- client cannot see monthly_fee_cents through direct view if views exist
- team sees assigned client
- team cannot see unassigned client
- operator sees all clients
- operator cannot change pricing
- owner can change pricing
- team_client_assignments works
- inactive assignment blocks access
- client can create own request
- client cannot create request for another client
- onboarding ownership works
- client_platform internal notes hidden or flagged as portal-connect requirement

## Final report

Report:
- files created
- no migrations run
- AUTH_MODE unchanged
- how to run manually in Supabase
- known risks
- pass criteria
