# Supabase Migration Roadmap

## Current status

M001 Identity Foundation:
- Applied in dev Supabase
- Seeded and tested live
- Green enough

M002+:
- Not applied yet

## Migration order

### M001 — Identity Foundation
Tables:
- user_profiles
- team_members

Helpers:
- current_user_role()
- current_user_client_id()
- is_owner()
- is_operator()
- is_team_member()
- is_system_actor()

Status:
- Applied and tested in dev
- Do not rerun unless reset

### M002 — Client Foundation
Tables:
- clients
- team_client_assignments
- client_platforms
- onboarding_items
- client_requests
- user_profiles.client_id FK

Next task:
Prepare dev test package:
- 01_apply_m002.sql
- 02_seed_m002_dev_data.sql
- 03_test_m002_queries.sql
- 04_m002_test_results.md

### M003 — Media Foundation
Tables:
- media_assets
- notifications
- client_health_snapshots
- activity_logs

Correction:
- notifications status guard

### M004 — Posting Foundation
Tables:
- posts
- post_slots

Correction:
- post slot reset trigger

### Portal Connect Pass
Views:
- client_portal_clients_view
- client_portal_platforms_view
- client_portal_onboarding_view
- client_portal_requests_view
- client_portal_media_view
- client_portal_notifications_view
- client_portal_health_view
- client_portal_calendar_view

Must happen before real client credentials.

### M005 — Reporting Foundation
Tables:
- weekly_reports
- monthly_reports

Views:
- client_portal_weekly_reports_view
- client_portal_monthly_reports_view

### M006 — Content + AI Layer
Tables:
- content_concepts
- draft_sets
- draft_variants
- ai_agents

No real AI APIs yet.

## Real client credentials rule

Do not issue real client credentials until:
1. M001-M004 applied and tested
2. notification guard applied and tested
3. post slot reset guard applied and tested
4. portal-connect views applied and tested
5. portal code uses views, not base tables
