# Veroxa Complete Replit Build Package

This ZIP is designed for Replit to use as a complete build/context package for Veroxa.

## Important

This package is meant to help Replit build or rebuild Veroxa accurately.

If the existing GitHub repo is available, GitHub main should still be treated as the source of truth.

If Replit is building from zero, use this package as the full product specification and build roadmap.

## Current locked Veroxa checkpoint

- Brand: Veroxa
- Business: restaurant marketing operating system / agency platform
- Public website + role-based portal system
- Roles: Client, Team, Operator, Owner
- Avoid "Super Admin" language
- AUTH_MODE must remain `"placeholder"` until real Supabase auth is intentionally activated
- M001 Identity Foundation has been applied and live-tested in dev Supabase
- Do not apply M002+ until test packages are prepared and reviewed
- Real client credentials must not be issued until portal-connect views are applied and tested

## Locked Pricing

Google Presence Starter:
- $497/month

Complete Online Presence:
- 12-month: $997/month
- 6-month: $1,097/month
- 3-month: $1,197/month
- No-contract: $1,497/month

Ads:
- Ads add-on: $1,500/month
- Ads-only: $2,000/month

Bundles:
- 12-month: $1,797/month
- 6-month: $1,897/month
- 3-month: $1,997/month
- No-contract: $2,297/month

## First instruction to Replit

Read this ZIP fully before building. Then open `00_REPLIT_MASTER_BUILD_INSTRUCTIONS.md`.
