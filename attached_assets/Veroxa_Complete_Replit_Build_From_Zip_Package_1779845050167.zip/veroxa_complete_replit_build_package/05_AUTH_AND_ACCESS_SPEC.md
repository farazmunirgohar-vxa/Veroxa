# Auth and Access Spec

## AUTH_MODE

Create:

src/lib/auth/authMode.ts

```ts
export type AuthMode = "placeholder" | "real";

export const AUTH_MODE: AuthMode = "placeholder";
```

Do not set this to real until:
- M001 applied
- M002+ applied as needed
- RLS tested
- test users created
- portal-connect views applied and tested
- env vars set
- real auth QA completed

## Placeholder demo access

Client portal:
- public

Team/Operator/Owner:
- demo access gate

Access code:
```text
veroxa-preview
```

localStorage key:
```text
veroxa_demo_internal_access
```

## InternalDemoGuard behavior

If AUTH_MODE = placeholder:
- client routes are public
- internal routes require demo access code

If AUTH_MODE = real:
- use Supabase auth path
- verify user role
- block wrong roles

## Role names

Allowed roles:
- client
- team
- operator
- owner

Do not use:
- admin
- super_admin
- super admin
