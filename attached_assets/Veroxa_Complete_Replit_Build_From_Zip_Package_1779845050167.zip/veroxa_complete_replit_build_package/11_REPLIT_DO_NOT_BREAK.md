# Do Not Break List

Replit must not change these unless explicitly requested:

- AUTH_MODE must remain placeholder
- Locked pricing
- Role names
- Demo access code
- Portal nav structure
- Client portal simplicity
- SQL drafts staying outside supabase/migrations
- No real migrations run automatically
- No Supabase connection without human approval
- No AI APIs
- No publishing APIs
- No payment processing
- No old pricing
- No "Super Admin"

## Locked pricing strings to protect

- $497
- $997
- $1,097
- $1,197
- $1,497
- $1,500
- $2,000
- $1,797
- $1,897
- $1,997
- $2,297

Bad old values to avoid as locked base pricing:
- $1,000
- $1,100
- $1,200
- $1,500 as no-contract base if replacing $1,497
- 7-month
