# Frontend Build Spec

## Stack

Recommended:
- React + Vite or existing Replit React scaffold
- TypeScript preferred
- Tailwind or existing styling system
- Dark premium SaaS UI

## Required shared components

- DashboardLayout
- PageHeader
- SectionCard
- MetricCard
- StatusBadge
- EmptyState
- PortalNav
- DemoInternalGate
- PricingCard

## Public Website Pages

### Home
Sections:
- Hero
- What Veroxa does
- Restaurant pain point
- System overview
- Portal preview
- Pricing CTA
- Contact CTA

### Pricing
Must include locked pricing exactly.

Google Presence Starter:
- $497/mo

Complete Online Presence:
- 12-month $997/mo
- 6-month $1,097/mo
- 3-month $1,197/mo
- No-contract $1,497/mo

Optional ads/bundles can be shown if room exists.

### Login
Role cards:
- Client Portal — Public Preview
- Team Portal — Demo Access Required
- Operator Portal — Demo Access Required
- Owner Portal — Demo Access Required

Links:
- Client: `/demo/client/dashboard`
- Team: `/demo/team/dashboard`
- Operator: `/demo/operator/operator-os`
- Owner: `/demo/owner/executive-dashboard`

## Client Portal Pages

Dashboard:
- This week snapshot
- Upload status
- Upcoming posts
- Latest report
- Recent activity

Upload Media:
- Simple upload guidance
- Best content examples
- Media status
- No internal AI scoring

Calendar:
- Scheduled
- Posted
- Waiting on content

Reports:
- Weekly/monthly client-safe reports

Requests:
- Simple client communication/request tracker

Account:
- Business info
- Plan
- Contact
- Upload commitment
- Support

## Team Portal Pages

Dashboard:
- Today's execution summary
- queue counts
- blocked items

Work Queue:
- needs review
- ready to draft
- ready to schedule
- report pending

Media Review:
- uploaded media
- quality status
- next actions

Drafts:
- caption draft variants
- approve/edit flow

Scheduling:
- upcoming slots
- scheduled posts

Reports:
- weekly draft/report queue

Alerts:
- operational alerts

## Operator Portal Pages

Command Center:
- clients needing attention
- monthly approvals
- alerts
- team capacity
- system health

Client Health:
- healthy/caution/urgent/broken

Alerts:
- critical / needs attention / resolved

Report Approvals:
- monthly report approval queue

Media Library:
- oversight-level media patterns

Team Oversight:
- workload and status

System Status:
- demo-only / future integration / placeholder status

## Owner Portal Pages

Executive Dashboard:
- revenue snapshot
- active clients
- client health
- critical alerts
- growth trend
- system health

Revenue:
- MRR
- plan mix
- pricing cards
- starter vs complete

Client Health:
- executive risk summary

Critical Alerts:
- serious business alerts only

AI/System Health:
- AI agent readiness
- demo status
- system confidence

Growth:
- pipeline/retention/growth

Settings:
- owner-level settings placeholder
