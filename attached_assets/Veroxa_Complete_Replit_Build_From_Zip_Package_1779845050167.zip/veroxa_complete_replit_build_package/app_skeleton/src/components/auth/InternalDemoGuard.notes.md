# InternalDemoGuard Required Behavior

- Client Portal public
- Team/Operator/Owner require demo access code while AUTH_MODE = placeholder
- Access code: veroxa-preview
- localStorage key: veroxa_demo_internal_access
- Do not call Supabase while placeholder mode is active
- Preserve real auth path for future
