export type AuthMode = "placeholder" | "real";

export const AUTH_MODE: AuthMode = "placeholder";
