# Human Baby Steps — M002

Use after Replit creates the M002 package.

1. Open Supabase dev project.
2. Confirm M001 tables exist:
   - user_profiles
   - team_members
3. Confirm M001 seed users exist.
4. Open `01_apply_m002.sql`.
5. Run it once.
6. If error: stop and report.
7. Open `02_seed_m002_dev_data.sql`.
8. Replace UUID placeholders.
9. Run seed.
10. Confirm two fake clients exist.
11. Run `03_test_m002_queries.sql` one block at a time.
12. Record results in `04_m002_test_results.md`.
13. Do not run M003 until M002 is green.
