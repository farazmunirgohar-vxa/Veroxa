# Before Any Real Client Credentials

Do not issue real client credentials until all are true:

- M001 applied and tested green.
- M002 applied and tested green.
- M003 applied and tested green.
- Notification status guard applied and tested green.
- M004 applied and tested green.
- Post slot reset guard applied and tested green.
- Portal-connect views applied and tested green.
- Portal query safety audit confirms client portal only queries client-safe views.
- AUTH_MODE switch plan reviewed.
- Rollback/snapshot plan exists.
- No real client can query sensitive base tables directly.
