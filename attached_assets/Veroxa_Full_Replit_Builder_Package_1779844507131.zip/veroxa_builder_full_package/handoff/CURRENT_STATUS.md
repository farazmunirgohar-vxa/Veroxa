# Current Veroxa Status

## Completed

### Product / portal
- Public site and demo portals exist.
- Client, Team, Operator, and Owner role structure exists.
- Client portal is public preview.
- Team / Operator / Owner internal demo gate exists.
- Login page should say `Demo Access Required` for internal portals.
- Demo code is `veroxa-preview`.

### Backend planning
- Demo data split is complete.
- Schema planning is complete through M006.
- RLS planning is complete through M006.
- Draft SQL exists through M006.
- Portal-connect views draft exists.
- Notification status guard draft exists.
- Post slot reset trigger draft exists.
- Portal query safety plan exists.

### Supabase dev testing
- M001 was applied to dev Supabase after partial-install cleanup.
- Dev Auth users were created:
  - client@veroxa.test
  - team@veroxa.test
  - operator@veroxa.test
  - owner@veroxa.test
- `public.user_profiles` was seeded.
- `public.team_members` was seeded.
- Important M001 RLS/security tests passed:
  - anon blocked
  - client own-only
  - team own-only
  - operator read-only
  - owner privileged
  - role escalation blocked
  - email tampering blocked
  - private helper direct-call blocked for authenticated role

## Not completed

- M002 has not been applied.
- M003 has not been applied.
- M004 has not been applied.
- M005 has not been applied.
- M006 has not been applied.
- Portal-connect views have not been applied.
- Real auth has not been activated.
- Portal has not been connected to Supabase.
- No real client credentials should be issued.
