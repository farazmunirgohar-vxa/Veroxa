# Do Not Break Rules

Replit must not:

1. Change `AUTH_MODE` from `"placeholder"`.
2. Activate real Supabase auth.
3. Connect the frontend portal to Supabase yet.
4. Run M002–M006 unless explicitly instructed.
5. Move draft SQL files into `supabase/migrations`.
6. Add real AI API calls.
7. Add real publishing APIs.
8. Add payment processing.
9. Change locked pricing.
10. Rename roles away from Client / Team / Operator / Owner.
11. Replace the demo gate with fake production auth.
12. Remove the demo access code behavior.
13. Add new dashboard noise or new nav items.
14. Rebuild the UI from scratch.
15. Use real client data or real restaurant data.
