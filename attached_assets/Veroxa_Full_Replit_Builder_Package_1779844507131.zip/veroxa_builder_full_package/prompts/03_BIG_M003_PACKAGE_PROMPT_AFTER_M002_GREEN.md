# Big Prompt — Prepare M003 Dev Supabase Test Package

Use only after M002 has been manually applied and tested green.

Objective:
Prepare the M003 Media Foundation dev test package.

Do not apply anything.

Create:
`docs/sql_drafts/dev_test/m003/`

Files:
1. README.md
2. 01_apply_m003.sql
3. 02_seed_m003_dev_data.sql
4. 03_test_m003_queries.sql
5. 04_m003_test_results.md
6. M003_EXECUTION_SUMMARY.md

M003 includes:
- media_assets
- notifications
- client_health_snapshots
- activity_logs

Also include the M003 correction draft:
- notifications status guard

Test:
- client uploads own media only
- client cannot upload for another client
- client insert pins source_type and review_status
- client cannot edit review_status
- team can review assigned client media
- team cannot review unassigned media
- notifications client can only mark seen/dismissed after guard
- activity_logs hidden from client
- health snapshots simplified for client later
