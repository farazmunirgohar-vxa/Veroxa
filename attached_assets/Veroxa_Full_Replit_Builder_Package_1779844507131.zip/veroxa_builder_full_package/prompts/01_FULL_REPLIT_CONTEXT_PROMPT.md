# Full Context Prompt for Replit

You are continuing the Veroxa build.

Current checkpoint:
- M001 has been applied and security-tested in a dev Supabase project.
- M001 is green enough to prepare M002.
- M002–M006 should not be applied yet.
- AUTH_MODE must remain `"placeholder"`.
- The portal must not be connected to Supabase yet.
- No production data.
- No real client credentials.
- No UI rebuild.

Primary source of truth:
- Current GitHub main.

Uploaded ZIPs are only context.

Your next task is to prepare a large M002 dev test package that the human can run manually in Supabase Dashboard SQL Editor.

Do not ask for service-role keys.
Do not put secrets into the repo.
Do not run migrations from Replit unless a proper dev database connection is explicitly provided outside the repo.

You must create human-executable files under:

`docs/sql_drafts/dev_test/m002/`

Create:
1. `README.md`
2. `01_apply_m002.sql`
3. `02_seed_m002_dev_data.sql`
4. `03_test_m002_queries.sql`
5. `04_m002_test_results.md`
6. `M002_EXECUTION_SUMMARY.md`

Do not modify app behavior.
Do not change auth mode.
Do not touch pricing or navigation.
