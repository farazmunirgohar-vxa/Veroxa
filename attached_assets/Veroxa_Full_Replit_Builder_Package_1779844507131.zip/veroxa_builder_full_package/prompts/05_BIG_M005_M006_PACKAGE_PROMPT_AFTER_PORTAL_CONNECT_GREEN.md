# Big Prompt — Prepare M005 + M006 Dev Test Packages

Use only after M004 and portal-connect views are green.

Objective:
Prepare reporting and content/AI schema dev test packages.

Do not connect real AI.
Do not apply anything.

Create:
`docs/sql_drafts/dev_test/m005/`
and
`docs/sql_drafts/dev_test/m006/`

M005:
- weekly_reports
- monthly_reports
- client-safe report views

M006:
- content_concepts
- draft_sets
- draft_variants
- ai_agents
- posts concept/draft FKs

Tests:
- client sees only published reports
- internal report notes hidden
- team cannot final approve monthly reports
- operator can approve monthly reports
- client cannot access concepts/drafts/variants
- owner controls ai_agents enable/disable
- no real AI calls
