# Big Prompt — Prepare M002 Dev Supabase Test Package

Objective:
Prepare a complete, human-executable M002 dev Supabase test package.

This is package generation only.

Do NOT:
- apply M002
- run migrations
- move SQL into `supabase/migrations`
- connect the portal
- activate real auth
- change AUTH_MODE
- change pricing
- change navigation
- use production data

Keep `AUTH_MODE = "placeholder"`.

## Read first

Read:
- `docs/sql_drafts/migrations_review/002_client_foundation_draft.sql`
- `docs/MIGRATION_002_TEST_PLAN.md`
- `docs/SUPABASE_SCHEMA_DRAFT_V1.md`
- `docs/SUPABASE_RLS_PLAN_V1.md`
- `docs/PORTAL_QUERY_SAFETY_PLAN.md`
- `docs/sql_drafts/migrations_review/001_identity_foundation_draft.sql`
- M001 dev test package if present

## Create package folder

Create:

`docs/sql_drafts/dev_test/m002/`

## File 1 — README.md

Explain:
- M001 must already be applied and green.
- Run only M002.
- Do not run M003–M006.
- Use fake dev data only.
- Portal remains disconnected.
- AUTH_MODE remains placeholder.
- Real client credentials must not be issued.

## File 2 — 01_apply_m002.sql

Create a clean apply script derived from:
`docs/sql_drafts/migrations_review/002_client_foundation_draft.sql`

Rules:
- Keep comments.
- Remove or adjust “DO NOT RUN” header only if this is specifically for dev SQL Editor manual execution.
- Still clearly mark: DEV ONLY, NOT PRODUCTION.
- Include no M003+ objects.

Expected M002 objects:
- `clients`
- `team_client_assignments`
- `client_platforms`
- `onboarding_items`
- `client_requests`
- `user_profiles.client_id` FK
- M002 helper functions
- M002 RLS policies
- M002 indexes/triggers
- client-safe view stubs only if already part of M002 draft; real portal-connect views are separate later.

## File 3 — 02_seed_m002_dev_data.sql

Use existing M001 dev users:
- client@veroxa.test
- team@veroxa.test
- operator@veroxa.test
- owner@veroxa.test

The human may need to replace UUIDs with actual UUIDs from Supabase Auth. Include a clear UUID config section at top.

Seed fake dev data only:
- 2 fake clients:
  - Dev Restaurant A
  - Dev Restaurant B
- link client user to Dev Restaurant A using `user_profiles.client_id`
- assign team member to Dev Restaurant A only via `team_client_assignments`
- create platform rows for both clients
- create onboarding items for both clients
- create client requests for both clients

Do not seed real restaurant names.

## File 4 — 03_test_m002_queries.sql

Create baby-step test blocks with expected results.

Tests must verify:
- Client sees only own client.
- Client cannot see client B.
- Client cannot see monthly_fee_cents if using client-safe view.
- Client cannot update pricing fields.
- Team sees only assigned client.
- Team cannot see unassigned client.
- Operator sees all clients.
- Operator cannot update monthly_fee_cents.
- Owner can update pricing fields.
- team_client_assignments active/inactive behavior works.
- client_platforms notes are hidden from client-safe view if view exists.
- onboarding item ownership rules work.
- client can create own request.
- client cannot create request for another client.
- no old `assigned_client_ids` array exists.

Use actual UUID placeholders at top:
- OWNER_UUID
- OPERATOR_UUID
- TEAM_UUID
- CLIENT_UUID
- CLIENT_A_ID
- CLIENT_B_ID
- TEAM_MEMBER_ID

Make it easy for the human to replace values.

## File 5 — 04_m002_test_results.md

Create a table:
- Test ID
- Description
- Expected
- Actual
- Pass/Fail
- Notes

## File 6 — M002_EXECUTION_SUMMARY.md

Summarize:
- What this package does
- What it does not do
- Required preconditions
- Stop conditions
- What to do after all tests pass

## Final report required

Report:
1. Files created
2. Whether M001 precondition was documented
3. Whether M002 apply SQL was generated
4. Whether seed SQL was generated
5. Number of M002 test blocks
6. Confirmation no migrations were run
7. Confirmation no AUTH_MODE change
8. Confirmation no app behavior changed
9. Recommended human execution order
