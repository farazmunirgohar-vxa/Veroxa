# Big Prompt — Prepare M004 + Portal-Connect Dev Test Packages

Use only after M003 is green.

Objective:
Prepare M004 posting package and portal-connect views package.

Do not apply anything.

Create:
`docs/sql_drafts/dev_test/m004/`
and
`docs/sql_drafts/dev_test/portal_connect/`

M004 includes:
- posts
- post_slots
- media_assets.linked_post_id FK
- post slot reset guard

Portal-connect includes:
- client_portal_clients_view
- client_portal_platforms_view
- client_portal_onboarding_view
- client_portal_requests_view
- client_portal_media_view
- client_portal_notifications_view
- client_portal_health_view
- client_portal_calendar_view

Tests:
- client sees safe calendar only
- client cannot see concept_id/draft_variant_id
- team can manage assigned posts
- team cannot manage unassigned posts
- slot unique constraint
- deleting reserved post resets slot
- client-safe views hide sensitive columns
