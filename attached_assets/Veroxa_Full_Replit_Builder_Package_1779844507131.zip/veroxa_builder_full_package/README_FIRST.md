# Veroxa Full Replit Builder Package

This package is for Replit to understand the current Veroxa build state and continue safely with larger controlled work blocks.

## Current source of truth

Primary source of truth: GitHub main for `farazmunirgohar-vxa/Veroxa`.

ZIP uploads are progress context only.

## Current checkpoint

- Veroxa frontend demo is already built and polished enough for now.
- Team / Operator / Owner demo portals should require the demo access code.
- Demo access code: `veroxa-preview`
- Client demo portal remains public.
- `AUTH_MODE` must remain `"placeholder"`.
- M001 Identity Foundation has been applied and manually tested in a dev Supabase project.
- M001 is considered green enough to prepare M002.
- M002–M006 are planned/drafted, but not applied yet.
- Real client credentials must not be issued yet.
- Real production auth must not be activated yet.

## Golden rule

Do not change UI, pricing, navigation, or auth mode while preparing backend test packages.

## Locked pricing

Google Presence Starter: $497/mo

Complete Online Presence:
- 12-month: $997/mo
- 6-month: $1,097/mo
- 3-month: $1,197/mo
- No-contract: $1,497/mo
