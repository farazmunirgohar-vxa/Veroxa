# Veroxa Build Roadmap — Larger Blocks

This roadmap replaces tiny one-off prompts with larger safe build blocks.

## Block A — M002 Dev Test Package
Prepare M002 dev testing package only. Do not apply M002.

Outputs:
- Clean apply SQL for M002
- Seed SQL for fake clients/platforms/onboarding/requests
- Test SQL blocks
- Results sheet
- Human run instructions

## Block B — M002 Manual Dev Test
Human applies M002 in dev Supabase and runs tests.
Replit should not require service-role keys in repo.

## Block C — M003 Dev Test Package
After M002 is green, prepare M003 media/notifications/activity/health package.

## Block D — M004 Dev Test Package
After M003 is green, prepare posts/post_slots package.

## Block E — Portal-Connect Views Test Package
After M004 is green, prepare and test client-safe views.

## Block F — M005 Reporting Dev Test Package
After M004 + portal views are green, prepare weekly/monthly reports package.

## Block G — M006 Content/AI Schema Test Package
Prepare M006 schema only. No real AI.

## Block H — Portal Connection Planning
Only after backend layers pass dev testing, plan connecting client portal pages to client-safe views.
