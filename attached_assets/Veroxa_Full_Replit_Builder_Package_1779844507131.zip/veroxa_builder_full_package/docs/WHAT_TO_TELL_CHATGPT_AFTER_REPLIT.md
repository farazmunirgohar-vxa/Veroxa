# What to Tell ChatGPT After Replit Creates the Package

Paste Replit's final report and say:

`Review the M002 dev package and give me baby-step execution instructions.`

Do not apply M002 until ChatGPT reviews the generated package.

If you already applied M002 and got an error, send:
1. screenshot
2. exact SQL file
3. exact step number
4. error message
